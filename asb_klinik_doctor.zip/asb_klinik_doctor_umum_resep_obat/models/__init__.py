# -*- coding: utf-8 -*-

from . import master_registration
from . import resep_obat
from . import detail_obat
