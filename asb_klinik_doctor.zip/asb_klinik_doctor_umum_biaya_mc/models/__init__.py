# -*- coding: utf-8 -*-

from . import master_registration
