# -*- coding: utf-8 -*-

from . import pemeriksaan_fisik_master
from . import kulit_skin
from . import mata_eye
from . import tht_ent
from . import mulut_mouth
from . import leher_neck
from . import dada_chest
from . import extrimitas_extrimities
from . import sensorik_examination
from . import motorik_examination
from . import reflek_examination
from . import limfatik_sistem
from . import perut_abdomen
from . import rectal_examintaion
from . import muskuloskletal_examination
from . import other_examination
