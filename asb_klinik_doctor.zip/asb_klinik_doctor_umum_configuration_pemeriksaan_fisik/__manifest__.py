# -*- coding: utf-8 -*-
{
    'name': 'Doctor Umum Configuration Pemeriksaan Fisik',
    'version': '0.1',
    'author': 'PT Arkana Solusi Bisnis',
    'license': 'OPL-1',
    'category': 'Doctor Configuration Pemeriksaan Fisik',
    'website': 'http://www.arkana.co.id',
    'summary': 'Custom Doctor Configuration Pemeriksaan Fisik',
    'description': '''
        Custom doctor configuration pemeriksaan fisik module for Medika
    ''',
    'depends': ['base', 'mail', 'portal', 'asb_klinik_doctor_umum_configuration', 'asb_klinik_doctor_umum_antrian_pasien'],

    'data': [
        'security/ir.model.access.csv',

        'views/assets.xml',

        'views/pemeriksaan_fisik_master_views.xml',

        'views/pemeriksaan_fisik_master_kulit_skin_views.xml',
        'views/pemeriksaan_fisik_master_mata_eye_views.xml',
        'views/pemeriksaan_fisik_master_tht_ent_views.xml',
        'views/pemeriksaan_fisik_master_mulut_mouth_views.xml',
        'views/pemeriksaan_fisik_master_leher_neck_views.xml',
        'views/pemeriksaan_fisik_master_dada_chest_views.xml',
        'views/pemeriksaan_fisik_master_extrimitas_extrimities_views.xml',
        'views/pemeriksaan_fisik_master_muskuloskletal_examination_views.xml',
        'views/pemeriksaan_fisik_master_sensorik_examination_views.xml',
        'views/pemeriksaan_fisik_master_motorik_examination_views.xml',
        'views/pemeriksaan_fisik_master_reflek_examination_views.xml',
        'views/pemeriksaan_fisik_master_limfatik_sistem_views.xml',

        'views/kulit_skin_views.xml',
        'views/mata_eye_views.xml',
        'views/tht_ent_views.xml',
        'views/mulut_mouth_views.xml',
        'views/leher_neck_views.xml',
        'views/dada_chest_views.xml',
        'views/perut_abdomen_views.xml',
        'views/extrimitas_extrimities_views.xml',
        'views/rectal_examination_views.xml',
        'views/muskuloskletal_examination_views.xml',
        'views/sensorik_examination_views.xml',
        'views/motorik_examination_views.xml',
        'views/reflek_examination_views.xml',
        'views/other_examination_views.xml',
        'views/limfatik_sistem_views.xml',

        'data/pemeriksaan_fisik_master_data.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
