# -*- coding: utf-8 -*-
{
    'name': 'Doctor Umum Configuration',
    'version': '0.1',
    'author': 'PT Arkana Solusi Bisnis',
    'license': 'OPL-1',
    'category': 'Doctor Configuration',
    'website': 'http://www.arkana.co.id',
    'summary': 'Custom Doctor Configuration',
    'description': '''
        Custom doctor configuration module for Medika
    ''',
    'depends': ['base', 'mail', 'portal', 'asb_klinik_doctor'],

    'data': [
        'views/doctor_configuration_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
