# -*- coding: utf-8 -*-

from . import lifestyle_merokok_wizard
from . import lifestyle_olahraga_wizard
