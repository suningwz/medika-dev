# -*- coding: utf-8 -*-
{
    'name': 'Doctor Umum Configuration Anamnesa',
    'version': '0.1',
    'author': 'PT Arkana Solusi Bisnis',
    'license': 'OPL-1',
    'category': 'Doctor Configuration Anamnesa',
    'website': 'http://www.arkana.co.id',
    'summary': 'Custom Doctor Configuration Anamnesa',
    'description': '''
        Custom doctor configuration anamnesa module for Medika
    ''',
    'depends': ['base', 'mail', 'portal', 'asb_klinik_doctor_umum_configuration', 'asb_klinik_doctor_umum_antrian_pasien'],

    'data': [
        'security/ir.model.access.csv',

        'views/anamnesa_master_views.xml',

        'views/anamnesa_master_family_history_views.xml',
        'views/anamnesa_master_medical_history_views.xml',
        'views/anamnesa_master_lifestyle_views.xml',
        'views/anamnesa_master_special_for_woman_views.xml',
        'views/anamnesa_master_work_exposure_physical_views.xml',
        'views/anamnesa_master_work_exposure_chemical_views.xml',
        'views/anamnesa_master_work_exposure_biology_views.xml',
        'views/anamnesa_master_work_exposure_ergonomics_views.xml',
        'views/anamnesa_master_work_exposure_psyichology_views.xml',
        'views/anamnesa_master_work_exposure_other_views.xml',

        'views/family_history_views.xml',
        'views/medical_history_views.xml',
        'views/lifestyle_views.xml',
        'views/special_for_woman_views.xml',
        'views/work_exposure_physical_views.xml',
        'views/work_exposure_chemical_views.xml',
        'views/work_exposure_biology_views.xml',
        'views/work_exposure_ergonomics_views.xml',
        'views/work_exposure_psyichology_views.xml',
        'views/work_exposure_other_views.xml',

        'wizard/lifestyle_merokok_wizard_views.xml',
        'wizard/lifestyle_olahraga_wizard_views.xml',

        'data/anamnesa_master_data.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
