# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class sistemlimfatik(models.Model):
    _name = 'sistem.limfatik'
    _description = 'sistem limfatik'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(sistemlimfatik, self).create(vals)
        vals = {'limfatik_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'limfatik_line': x})
        return res

class sistemlimfatikLine(models.Model):
    _name = 'sistem.limfatik.line'
    _description = 'sistem limfatik Line'
    _rec_name = 'limfatik_id'
    
    limfatik_id = fields.Many2one('sistem.limfatik', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    limfatik_line = fields.One2many('sistem.limfatik.line', 'doctor_umum_antrian_pasien_id', string='sistem/limfatik')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        limfatik_line = []
        limfatik_rec = self.env['sistem.limfatik'].search([])
        for rec in limfatik_rec:
            line = (0, 0,{
                'limfatik_id': rec.id
            })
            limfatik_line.append(line)
        res.update({
            'limfatik_line': limfatik_line
        })
        return res
