# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class StatusOther(models.Model):
    _name = 'status.other'
    _description = 'Status Other'
    
    name = fields.Char(string='Nama')
    other = fields.Selection([
        ('koordinasi', 'Koordinasi'),
        ('romberg', 'Romberg'),
    ], string='Other')