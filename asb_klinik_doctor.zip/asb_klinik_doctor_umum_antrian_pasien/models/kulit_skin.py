# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class KulitSkin(models.Model):
    _name = 'kulit.skin'
    _description = 'Kulit Skin'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(KulitSkin, self).create(vals)
        vals = {'skin_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'skin_line': x})
        return res

class KulitSkinLine(models.Model):
    _name = 'kulit.skin.line'
    _description = 'Kulit Skin Line'
    _rec_name = 'skin_id'
    
    skin_id = fields.Many2one('kulit.skin', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    skin_line = fields.One2many('kulit.skin.line', 'doctor_umum_antrian_pasien_id', string='Kulit/Skin')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        skin_line = []
        skin_rec = self.env['kulit.skin'].search([])
        for rec in skin_rec:
            line = (0, 0,{
                'skin_id': rec.id
            })
            skin_line.append(line)
        res.update({
            'skin_line': skin_line
        })
        return res
