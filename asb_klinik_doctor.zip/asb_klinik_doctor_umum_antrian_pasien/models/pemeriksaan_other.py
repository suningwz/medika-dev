# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError


class PemeriksaanOther(models.Model):
    _name = 'pemeriksaan.other'
    _description = 'pemeriksaan other'

    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanOther, self).create(vals)
        vals = {'other_id': res.id, }
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'other_line': x})
        return res


class PemeriksaanOtherLine(models.Model):
    _name = 'pemeriksaan.other.line'
    _description = 'pemeriksaan other Line'
    _rec_name = 'other_id'

    other_id = fields.Many2one('pemeriksaan.other')
    status_id = fields.Many2one('status.other', string='Status',)
    status_ids = fields.Many2many('status.other', compute="_compute_status_id_domain", string='Status IDS',)
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

    @api.depends('other_id')
    def _compute_status_id_domain(self):
        for rec in self:
            if rec.other_id.name == 'Romberg Test':
                rec.status_ids = self.env['status.other'].search([('other', '=', 'romberg')])
            else:
                rec.status_ids = self.env['status.other'].search([('other', '=', 'koordinasi')])


class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'

    other_line = fields.One2many('pemeriksaan.other.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/other')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        other_line = []
        other_rec = self.env['pemeriksaan.other'].search([])
        status_romberg = self.env['status.other'].search([('name', '=', 'Negatif (Negative)')], limit=1)
        status_normal = self.env['status.other'].search([('name', '=', 'Normal (Normal)')], limit=1)
        for rec in other_rec:
            if rec.name == 'Romberg Test':
                line = (0, 0, {
                    'other_id': rec.id,
                    'status_id': status_romberg.id,
                })
            else:
                line = (0, 0, {
                    'other_id': rec.id,
                    'status_id': status_normal.id,
                })
            other_line.append(line)
        res.update({
            'other_line': other_line
        })
        return res
