# -*- coding: utf-8 -*-

from . import antrian_pasien
# from . import kulit_skin
# from . import mata_eye
# from . import tht_ent
# from . import mulut_mouth
# from . import leher_neck
# from . import dada_chest
# from . import perut_abdomen
# from . import extrimitas_extrimities
# from . import status_rectal
# from . import pemeriksaan_rectal
# from . import pemeriksaan_muskuloskletal
# from . import pemeriksaan_sensorik
# from . import pemeriksaan_motorik
# from . import status_other
# from . import pemeriksaan_other
# from . import pemeriksaan_reflek
# from . import sistem_limfatik
from . import plan
from . import pemeriksaan_diagnosis
from . import permintaan_lab
from . import permintaan_radiologi
from . import detail_pemeriksaan_mc
