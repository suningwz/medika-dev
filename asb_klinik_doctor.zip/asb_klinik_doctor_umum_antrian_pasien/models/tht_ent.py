# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class ThtEnt(models.Model):
    _name = 'tht.ent'
    _description = 'THT ENT'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(ThtEnt, self).create(vals)
        vals = {'ent_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'ent_line': x})
        return res

class ThtEntLine(models.Model):
    _name = 'tht.ent.line'
    _description = 'THT ENT Line'
    _rec_name = 'ent_id'
    
    ent_id = fields.Many2one('tht.ent', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    ent_line = fields.One2many('tht.ent.line', 'doctor_umum_antrian_pasien_id', string='Tht/Ent')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        ent_line = []
        ent_rec = self.env['tht.ent'].search([])
        for rec in ent_rec:
            line = (0, 0,{
                'ent_id': rec.id
            })
            ent_line.append(line)
        res.update({
            'ent_line': ent_line
        })
        return res
