# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class PemeriksaanReflek(models.Model):
    _name = 'pemeriksaan.reflek'
    _description = 'pemeriksaan reflek'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanReflek, self).create(vals)
        vals = {'reflek_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'reflek_line': x})
        return res

class PemeriksaanReflekLine(models.Model):
    _name = 'pemeriksaan.reflek.line'
    _description = 'pemeriksaan reflek Line'
    _rec_name = 'reflek_id'
    
    reflek_id = fields.Many2one('pemeriksaan.reflek', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    reflek_line = fields.One2many('pemeriksaan.reflek.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/reflek')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        reflek_line = []
        reflek_rec = self.env['pemeriksaan.reflek'].search([])
        for rec in reflek_rec:
            line = (0, 0,{
                'reflek_id': rec.id
            })
            reflek_line.append(line)
        res.update({
            'reflek_line': reflek_line
        })
        return res
