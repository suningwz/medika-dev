# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class PemeriksaanMotorik(models.Model):
    _name = 'pemeriksaan.motorik'
    _description = 'pemeriksaan motorik'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanMotorik, self).create(vals)
        vals = {'motorik_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'motorik_line': x})
        return res

class PemeriksaanMotorikLine(models.Model):
    _name = 'pemeriksaan.motorik.line'
    _description = 'pemeriksaan motorik Line'
    _rec_name = 'motorik_id'
    
    motorik_id = fields.Many2one('pemeriksaan.motorik', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    motorik_line = fields.One2many('pemeriksaan.motorik.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/motorik')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        motorik_line = []
        motorik_rec = self.env['pemeriksaan.motorik'].search([])
        for rec in motorik_rec:
            line = (0, 0,{
                'motorik_id': rec.id
            })
            motorik_line.append(line)
        res.update({
            'motorik_line': motorik_line
        })
        return res
