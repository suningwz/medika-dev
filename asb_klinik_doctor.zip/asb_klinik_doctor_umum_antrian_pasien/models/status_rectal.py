# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class StatusRectal(models.Model):
    _name = 'status.rectal'
    _description = 'Status Rectal'
    
    name = fields.Char(string='Nama')
    rectal = fields.Selection([
        ('hemorrhoid', 'Hemorrhoid'),
        ('anus', 'Anus (Rectum)'),
    ], string='Rectal')
