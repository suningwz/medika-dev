# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class PemeriksaanMuskuloskletal(models.Model):
    _name = 'pemeriksaan.muskuloskletal'
    _description = 'pemeriksaan muskuloskletal'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanMuskuloskletal, self).create(vals)
        vals = {'muskuloskletal_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'muskuloskletal_line': x})
        return res

class PemeriksaanMuskuloskletalLine(models.Model):
    _name = 'pemeriksaan.muskuloskletal.line'
    _description = 'pemeriksaan muskuloskletal Line'
    _rec_name = 'muskuloskletal_id'
    
    muskuloskletal_id = fields.Many2one('pemeriksaan.muskuloskletal', string='Name')
    status = fields.Selection([
        ('positif', 'Positif (Positive)'),
        ('negatif', 'Negatif (Negative)'),
    ], string='Status', default='negatif')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    muskuloskletal_line = fields.One2many('pemeriksaan.muskuloskletal.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/muskuloskletal')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        muskuloskletal_line = []
        muskuloskletal_rec = self.env['pemeriksaan.muskuloskletal'].search([])
        for rec in muskuloskletal_rec:
            line = (0, 0,{
                'muskuloskletal_id': rec.id
            })
            muskuloskletal_line.append(line)
        res.update({
            'muskuloskletal_line': muskuloskletal_line
        })
        return res
