# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class LeherNeck(models.Model):
    _name = 'leher.neck'
    _description = 'Leher Neck'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(LeherNeck, self).create(vals)
        vals = {'neck_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'neck_line': x})
        return res

class LeherNeckLine(models.Model):
    _name = 'leher.neck.line'
    _description = 'Leher Neck Line'
    _rec_name = 'neck_id'
    
    neck_id = fields.Many2one('leher.neck', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    neck_line = fields.One2many('leher.neck.line', 'doctor_umum_antrian_pasien_id', string='leher/neck')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        neck_line = []
        neck_rec = self.env['leher.neck'].search([])
        for rec in neck_rec:
            line = (0, 0,{
                'neck_id': rec.id
            })
            neck_line.append(line)
        res.update({
            'neck_line': neck_line
        })
        return res
