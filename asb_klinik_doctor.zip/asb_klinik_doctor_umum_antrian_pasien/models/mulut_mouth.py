# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class MulutMouth(models.Model):
    _name = 'mulut.mouth'
    _description = 'Mulut Mouth'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(MulutMouth, self).create(vals)
        vals = {'mouth_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'mouth_line': x})
        return res

class MulutMouthLine(models.Model):
    _name = 'mulut.mouth.line'
    _description = 'Mulut Mouth Line'
    _rec_name = 'mouth_id'
    
    mouth_id = fields.Many2one('mulut.mouth', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    mouth_line = fields.One2many('mulut.mouth.line', 'doctor_umum_antrian_pasien_id', string='mulut/mouth')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        mouth_line = []
        mouth_rec = self.env['mulut.mouth'].search([])
        for rec in mouth_rec:
            line = (0, 0,{
                'mouth_id': rec.id
            })
            mouth_line.append(line)
        res.update({
            'mouth_line': mouth_line
        })
        return res
