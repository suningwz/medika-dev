# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class ExtrimitasExtrimities(models.Model):
    _name = 'extrimitas.extrimities'
    _description = 'extrimitas extrimities'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(ExtrimitasExtrimities, self).create(vals)
        vals = {'extrimities_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'extrimities_line': x})
        return res

class ExtrimitasExtrimitiesLine(models.Model):
    _name = 'extrimitas.extrimities.line'
    _description = 'extrimitas extrimities Line'
    _rec_name = 'extrimities_id'
    
    extrimities_id = fields.Many2one('extrimitas.extrimities', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    extrimities_line = fields.One2many('extrimitas.extrimities.line', 'doctor_umum_antrian_pasien_id', string='extrimitas/extrimities')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        extrimities_line = []
        extrimities_rec = self.env['extrimitas.extrimities'].search([])
        for rec in extrimities_rec:
            line = (0, 0,{
                'extrimities_id': rec.id
            })
            extrimities_line.append(line)
        res.update({
            'extrimities_line': extrimities_line
        })
        return res
