# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class MataEye(models.Model):
    _name = 'mata.eye'
    _description = 'mata eye'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(MataEye, self).create(vals)
        vals = {'eye_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'eye_line': x})
        return res

class MataEyeLine(models.Model):
    _name = 'mata.eye.line'
    _description = 'mata eye Line'
    _rec_name = 'eye_id'
    
    eye_id = fields.Many2one('mata.eye', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    eye_line = fields.One2many('mata.eye.line', 'doctor_umum_antrian_pasien_id', string='Mata/Eye')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        eye_line = []
        eye_rec = self.env['mata.eye'].search([])
        for rec in eye_rec:
            line = (0, 0,{
                'eye_id': rec.id
            })
            eye_line.append(line)
        res.update({
            'eye_line': eye_line
        })
        return res
