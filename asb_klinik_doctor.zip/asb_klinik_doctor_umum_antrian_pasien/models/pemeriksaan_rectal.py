# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError


class PemeriksaanRectal(models.Model):
    _name = 'pemeriksaan.rectal'
    _description = 'pemeriksaan rectal'

    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanRectal, self).create(vals)
        vals = {'rectal_id': res.id, }
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'rectal_line': x})
        return res


class PemeriksaanRectalLine(models.Model):
    _name = 'pemeriksaan.rectal.line'
    _description = 'pemeriksaan rectal Line'
    _rec_name = 'rectal_id'

    rectal_id = fields.Many2one('pemeriksaan.rectal')
    status_id = fields.Many2one('status.rectal', string='Status',)
    status_ids = fields.Many2many('status.rectal', compute="_compute_status_id_domain", string='Status IDS',)
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

    @api.depends('rectal_id')
    def _compute_status_id_domain(self):
        for rec in self:
            if rec.rectal_id.name == 'Hemorrhoid':
                rec.status_ids = self.env['status.rectal'].search([('rectal', '=', 'hemorrhoid')])
            else:
                rec.status_ids = self.env['status.rectal'].search([('rectal', '=', 'anus')])


class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'

    rectal_line = fields.One2many('pemeriksaan.rectal.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/rectal')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        rectal_line = []
        rectal_rec = self.env['pemeriksaan.rectal'].search([])
        status_hemorrhoid = self.env['status.rectal'].search([('name', '=', 'Negatif (Negative)')], limit=1)
        status_normal = self.env['status.rectal'].search([('name', '=', 'Normal (Normal)')], limit=1)
        for rec in rectal_rec:
            if rec.name == 'Hemorrhoid':
                line = (0, 0, {
                    'rectal_id': rec.id,
                    'status_id': status_hemorrhoid.id,
                })
            else:
                line = (0, 0, {
                    'rectal_id': rec.id,
                    'status_id': status_normal.id,
                })
            rectal_line.append(line)
        res.update({
            'rectal_line': rectal_line
        })
        return res
