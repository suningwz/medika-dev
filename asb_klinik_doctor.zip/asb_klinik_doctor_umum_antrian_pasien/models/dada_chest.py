# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class DadaChest(models.Model):
    _name = 'dada.chest'
    _description = 'dada chest'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(DadaChest, self).create(vals)
        vals = {'chest_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'chest_line': x})
        return res

class DadaChestLine(models.Model):
    _name = 'dada.chest.line'
    _description = 'dada chest Line'
    _rec_name = 'chest_id'
    
    chest_id = fields.Many2one('dada.chest', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    chest_line = fields.One2many('dada.chest.line', 'doctor_umum_antrian_pasien_id', string='dada/chest')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        chest_line = []
        chest_rec = self.env['dada.chest'].search([])
        for rec in chest_rec:
            line = (0, 0,{
                'chest_id': rec.id
            })
            chest_line.append(line)
        res.update({
            'chest_line': chest_line
        })
        return res
