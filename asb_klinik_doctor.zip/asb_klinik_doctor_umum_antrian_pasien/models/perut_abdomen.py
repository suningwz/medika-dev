# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class PerutAbdomen(models.Model):
    _name = 'perut.abdomen'
    _description = 'perut abdomen'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PerutAbdomen, self).create(vals)
        vals = {'abdomen_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'abdomen_line': x})
        return res

class PerutAbdomenLine(models.Model):
    _name = 'perut.abdomen.line'
    _description = 'perut abdomen Line'
    _rec_name = 'abdomen_id'
    
    abdomen_id = fields.Many2one('perut.abdomen', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    abdomen_line = fields.One2many('perut.abdomen.line', 'doctor_umum_antrian_pasien_id', string='perut/abdomen')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        abdomen_line = []
        abdomen_rec = self.env['perut.abdomen'].search([])
        for rec in abdomen_rec:
            line = (0, 0,{
                'abdomen_id': rec.id
            })
            abdomen_line.append(line)
        res.update({
            'abdomen_line': abdomen_line
        })
        return res
