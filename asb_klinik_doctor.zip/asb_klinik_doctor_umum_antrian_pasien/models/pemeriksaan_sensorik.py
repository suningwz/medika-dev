# -*- coding: utf-8 -*-

from odoo import api, fields, models, exceptions, _
from odoo.exceptions import UserError, ValidationError

class PemeriksaanSensorik(models.Model):
    _name = 'pemeriksaan.sensorik'
    _description = 'pemeriksaan sensorik'
    
    name = fields.Char(string='Name')

    @api.model
    def create(self, vals):
        x = []
        res = super(PemeriksaanSensorik, self).create(vals)
        vals = {'sensorik_id': res.id,}
        x.append((0, 0, vals))
        doctor_umum_antrian_pasien_rec = self.env['master.registration'].search([])
        for rec in doctor_umum_antrian_pasien_rec:
            rec.write({'sensorik_line': x})
        return res

class PemeriksaanSensorikLine(models.Model):
    _name = 'pemeriksaan.sensorik.line'
    _description = 'pemeriksaan sensorik Line'
    _rec_name = 'sensorik_id'
    
    sensorik_id = fields.Many2one('pemeriksaan.sensorik', string='Name')
    status = fields.Selection([
        ('not_examined', 'Tidak Diperiksa (Not Examined)'),
        ('normal', 'Normal (Normal)'),
        ('abnormal', 'Tidak Normal (Abnormal)'),
    ], string='Status', default='normal')
    deskripsi = fields.Text(string='Deskripsi')
    doctor_umum_antrian_pasien_id = fields.Many2one('master.registration', string='Doctor Umum')

class MasterRegistration(models.Model):
    _inherit = 'master.registration'
    _description = 'Doctor Umum Antrian Pasien'
    
    sensorik_line = fields.One2many('pemeriksaan.sensorik.line', 'doctor_umum_antrian_pasien_id', string='pemeriksaan/sensorik')

    @api.model
    def default_get(self, fields):
        res = super(MasterRegistration, self).default_get(fields)
        sensorik_line = []
        sensorik_rec = self.env['pemeriksaan.sensorik'].search([])
        for rec in sensorik_rec:
            line = (0, 0,{
                'sensorik_id': rec.id
            })
            sensorik_line.append(line)
        res.update({
            'sensorik_line': sensorik_line
        })
        return res
