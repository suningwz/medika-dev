# -*- coding: utf-8 -*-
{
    'name': 'Doctor',
    'version': '0.1',
    'author': 'PT Arkana Solusi Bisnis',
    'license': 'OPL-1',
    'category': 'Doctor',
    'website': 'http://www.arkana.co.id',
    'summary': 'Custom Doctor',
    'description': '''
        Custom doctor module for Medika
    ''',
    'depends': ['base', 'mail', 'portal'],

    'data': [
        'views/doctor_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': True,
}
